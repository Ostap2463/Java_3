package ca.sheridancollege.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import ca.sheridancollege.model.User;

@Controller
public class HomeController {
	
	User user1 = new User();
	
	@PostMapping("/formPost")
	public String formPost(Model model, @RequestParam String firstName, @RequestParam String lastName) {
		String m = "My first ThymeLeaf Test";
		
		user1.setFirstName(firstName);
		user1.setLastName(lastName);
		
		String userData = user1.toString();
		
		model.addAttribute("user", userData);
		model.addAttribute("Message", m);
		return "formPost.html";
		}}


