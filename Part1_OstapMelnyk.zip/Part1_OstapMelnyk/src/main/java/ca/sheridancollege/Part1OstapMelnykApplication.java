package ca.sheridancollege;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Part1OstapMelnykApplication {

	public static void main(String[] args) {
		SpringApplication.run(Part1OstapMelnykApplication.class, args);
	}

}
