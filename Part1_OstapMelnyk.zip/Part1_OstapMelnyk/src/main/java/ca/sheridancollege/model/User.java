package ca.sheridancollege.model;

public class User {
	
	private String firstName;
	private String lastName;
	
	//get method
	public String getFirstName() {
		return firstName;
		}
	// Setting user first name
	public void setFirstName(String firstName) {
		this.firstName = firstName;
		}
	//get method
	public String getLastName() {
		return lastName;
		}
	// Setting user last name
	public void setLastName(String lastName) {
		this.lastName = lastName;
		}
	
	@Override 
	public String toString() {
		return "First Name: " + firstName + "  Last Name:  " + lastName;
		}
}