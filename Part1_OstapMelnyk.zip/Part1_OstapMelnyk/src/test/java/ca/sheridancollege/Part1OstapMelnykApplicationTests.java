package ca.sheridancollege;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Part1OstapMelnykApplicationTests {

	@Test
	void contextLoads() {
	}

}
