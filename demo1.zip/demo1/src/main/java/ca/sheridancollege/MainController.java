package ca.sheridancollege;

import java.util.ArrayList;

import ca.sheridancollege.Product;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class MainController {
	
	
	Product product = new Product();
	
	@GetMapping("/")
	public String rootPath(Model model) {
		
		model.addAttribute("product", product);
		
		return "index.html";
	}
	
	
	@RequestMapping(value = "/product", method = RequestMethod.POST)
		public String home(Model model,@RequestParam double unitPrice,@RequestParam int quantity,
				@RequestParam String desc,
				@RequestParam String productCode){
		
		product.setDesc(desc);
		product.setProductCode(productCode);
		product.setQuantity(quantity);
		product.setUnitPrice(unitPrice);

		model.addAttribute("product", product);
		
		return"result.html";
		
	}
	
	
}
