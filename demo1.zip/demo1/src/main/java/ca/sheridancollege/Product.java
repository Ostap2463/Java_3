package ca.sheridancollege;

public class Product {
	
	private String productCode;
	private String desc;
	private int quantity;
	private double unitPrice;
	
	public Product (String desc, String productCode, String quantity, String unitPrice) {
		this.desc = desc;
		this.productCode = productCode;
		this.unitPrice = Double.parseDouble(unitPrice);
		this.quantity = Integer.parseInt(quantity);
	}
	
	public Product() {
		
	}
	
	public void setUnitPrice (double unitPrice) {
		this.unitPrice = unitPrice;
	}
	
	public void setDesc (String desc) {
		this.desc = desc;
	}
	
	public void setQuantity (int quantity) {
		this.quantity = quantity;
	}
	
	public void setProductCode (String productCode) {
		this.productCode = productCode;
	}
	
	public String getDesc () {
		return desc;
	}
	
	public String getProductCode () {
		return productCode;
	}
	
	public double getUnitPrice () {
		return unitPrice;
	}
	
	public int getQuantity () {
		return quantity;
	}
	
}
