package ca.sheridancollege;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ClassExercise1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
