package ca.sheridancollege.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PostMapping;

import ca.sheridancollege.model.Loan;

@Controller
public class HomeController {
	
	Loan loan = new Loan();
	
	
	
	@PostMapping("/userData")
	public String userInput(Model model, double annualInterestRate, int numberOfYears,
		      double loanAmount ) {
		loan.setAnnualInterestRate(annualInterestRate);
		loan.setLoanAmount(loanAmount);
		loan.setNumberOfYears(numberOfYears);
		
		double t = loan.getTotalPayment();
		double m = loan.getMonthlyPayment();
		double l = loan.getLoanAmount();
		double y = loan.getNumberOfYears();
		String totalPayment = loan.currencyFormat(t);
		String monthlyPayment = loan.currencyFormat(m);
		String loanAmountt = loan.currencyFormat(l);
		
		
		model.addAttribute("TotalPayment", totalPayment);
		model.addAttribute("MonthlyPayment", monthlyPayment);
		model.addAttribute("LoanAmount", loanAmountt);
		model.addAttribute("NumberOfYears", y);
		
		return "userData";
	}

}
